//  This function is for an alert----> Single line comm
function fn() {
  alert("Button is clicked");
}

/*
Multi line comment

function fn() {
  alert("Button is clicked");
}
*/

// Output display ---> Console
console.log("Hello");

// ----------------------- Varibles----------------

// Global variables

// Var---> Not recommended

// var cont; // Declared a var type variables

// cont = 2; // Assigned value to varible cont

// console.log(cont);

// var cont2 = 5; // Declare + Assign
// console.log(cont2);

// // var cont2 = 23;
// // console.log(cont2);

// // let

// let a = 1; // declare + assign
// console.log("This is the value of a " + a);

// let b; // declare
// b = 20; // assign

// // const

// const dibba = 'VS "--->"  Code';
// console.log(dibba);

// //--------------------------Scope of variables---------

// // Block of code--->Function

// function fn() {
//   let local = 1;
//   console.log("This is my local variable : " + local);

//   console.log("This is my global var : " + b);
// }
// fn();

// // console.log("This is my local variable : " + local);

// // Global : It can be accessed anywehere in the program
// console.log("This is my global var : " + b);

// ----------------- Assignment Operators------

let a = 10;

console.log((a += 5)); // a = a + 5;

console.log(a + 5); // 15 + 5 = 20;

console.log(a);

let b = 15;

b -= 5;

console.log("Value of b is : " + b);

let c = 5;

c *= 5; // c = c*5;   5*5 = 25;
console.log("Value of c is : " + c);

let d = 10;

d /= 10; // d = d/10 ---> 1;
console.log("Value of d is : " + d);

let e = 13;
e %= 10; // e = e%10 ----> 10%10---> remainder
console.log("Value of e is : " + e);

// Camel Case
let myVar = "Nihal";

