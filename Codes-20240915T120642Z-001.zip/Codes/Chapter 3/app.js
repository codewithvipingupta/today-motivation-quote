// console.log("Hello");

//--------------------Data Types---------

// Number
// let a = 10;
// console.log(a);

// //  typeof()
// console.log(typeof a);

// // string
// a = "z";
// console.log(typeof a);

// // true : 1, false : 0

// // Boolean ----> Conditional statements
// let b = true;
// console.log("The value of b is : " + b);
// console.log(typeof b);

// // String
// let s = "true";
// console.log("The value of s is : " + s);

// // Undefined
// let u; // declare
// console.log(typeof u);


// // Null
// let n = null;
// console.log(n);
// console.log(typeof(n));


// let x = null;
// console.log(x);
// console.log(typeof(x));


// // Hw : typeof(null) ----> Object;

//--------------- Objects----------

// 1st Method : 

// let obj1 = {
// //  key :       Value
//     userName : "Nihal Singh",
//     rollNo : 12,
//     school : "xyz Public school",
// };


// console.log(obj1.userName);
// obj1.userName = "Nikhil Singh";
// console.log(obj1.userName);

// Destructuring

// const {userName, rollNo, school} = obj;
// console.log(userName);
// console.log(rollNo);
// console.log(school);

// console.log(obj);
// console.log(obj['userName']);
// console.log(obj.userName);


// 2nd Method---> new keyword

// const obj2 = new Object();

// //  objectName.key = value;
//     obj2.address = "Ram Nagar";
//     obj2.postOffice = "Shyam Nagar";

// // console.log(obj2);
// // console.log(obj2['address']);

// //--------- Methods in oBj-------

// // 1. assign

// Object.assign(obj2, obj1);

// // console.log(obj2);

// // 2. freeze

// // we cannot make any chnages in obj1
// Object.freeze(obj1);

// // obj1.userName = "Nikhil Singh";
// // console.log(obj1.userName);

// // 3. key

// console.log(Object.keys(obj1));

// // 4. Values
// console.log(Object.values(obj1));


// ------------------- Arrays--------------

// 1st Method ----> easy/ Mostly used

let arr1 = [1, 2, 3, 4, 5, 'Nihal', false];

arr1[8] = 123;

// console.log(arr1);

// Manipulate


// console.log("Element at index 5 is : " + arr1[5]);

// arr1[5] = 'Nikhil';

// console.log("Element at index 5 after change is : " + arr1[5]);



//console.log(arr1);

// Indexes

// console.log("Element at index 5 is : " + arr1[5]);

// console.log("Element at index 3 is : " + arr1[3]);

// console.log(arr1[0]);



// 2nd : Method----> new key

let arr2 = new Array();

//console.log(arr2);

// Put elements into array

arr2[0] = 11;

// arr2[1] = ?

arr2[2] = 123;

//console.log(arr2);

arr2.push(234);
arr2.push(1);

//console.log(arr2);

arr2.pop();
arr2.pop();
//console.log(arr2);


// 3rd Method ---> new

const arr3 = new Array(1, 2, 3, 4);
//console.log(arr3);


// Array methods

// 2. Concat

// console.log(arr2);
// console.log(arr3);

const arr4 = arr2.concat(arr3);
// console.log("New concatinated array is : " + arr4);

// console.log(arr4);

// 3. slice

//console.log(arr4);

// .slice (start_Index, end+1_index);

const arr5 = arr4.slice(3, 7);

// console.log(arr5);

// 4. indexof

// lets say i want to know the index of 4

// arr_name.indexOf(elem);

// console.log("The index of 17 in arr5 is : " + arr5.indexOf(17));

// 5. reverse

// arr_name.reverse();

// console.log("After reversing the arr5 the array looks like : " + arr5.reverse());

// 6. Join

// console.log("After joining arr5 : " + arr5.join());

let temp = arr5.join("-");
// console.log(temp);
// console.log(typeof(temp));

// sperator

// default seperator ---> ", "


// 7. sort

const alpha = ['a', 'z', 'x', 'v', 'c', 'b'];

console.log(alpha.sort());

const temp2 = [1, 22, 13, 0, 99, 15, 123, 14, 19];

console.log(temp2.sort((a, b)=> a-b));

// reson ???

// '1', '22', '13'

// compartor

// 1-22 = -11

// Negtaive a-b ====> a, b
// a-b = 0 a, b
// Positive a-b ====> b, a
