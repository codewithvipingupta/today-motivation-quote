// Comparators operatpors

// left ==  right

// If left and right are of different data types == ---> left, right ==> Common data type convertion

// left ===  right

// Check ---> The data type of left and right ----> Different ---> false

// Left and rigth are of same data type ---> === values compare

// True ---- > 1
// False ----> 0

// let a = '10';   // string
// let b = 10;    // Number

// a ----> Number
// b ----> String

// == Operator
//console.log(a == b);

// ==== Operator
// console.log(a === b);

//----------Not operator-----

// ! ----> 0 = 1;
// ! ----> 1 = 0;

// !0 = 1---> True;
// !1 = 0---> False;

// !true = false;
// !false = true;

//console.log(!false);

// Un-equality

// == , ===

// I need to check wether 5 and 10 are not equal !!!

// 5 ---- 10
// Not equal ---> True
// Equal ----> False

// 5 === 5 ---> !True ---> False
// 5 === 10 ---> !False ---> True

// == ---> !=
// ===  ---> !==

//console.log(5 !== '7');

// '5'    '5'---> !True---> false
// '5'    '7' ---> !False---> True

// ====
// number string ---> Different = !false---> True

// ----- If Statement--------

let condition = false;

// true === false ----> False

// !false = true;

// !condition ---> !false = true;

// if(!condition){
//     console.log("Condition is true");
// };

//------------ If else---------------

// let a = 10; // Number
// let b = 9; // Number

// 10 === 9

// 10 , 9 Un-equal

// 10 ===  9 ---> False
// 10 !== 9 ----> True

// if(a !== b){
//     console.log("Condition is true");
// }
// else{
//     console.log("Condition is false");
// };

//------- If - else if--------

// let x = 10;
// let y = 12;

// x + y === 10 + 12 = 22

// 22 === 13---> False
// 22 === 23 ---> False
// 22 === 22 ---> True

// if (x + y === 13)
// {
//   console.log("10 + 3 is = 13");
// }

// else if (x + y === 82)
// {
//     console.log("10 + 12 is = 22 second time");
// }

// // false
// else if (x + y === 92)
// {
//     console.log("10 + 12 is = 22");
// }

// else{
//     console.log("All the if and else if conditions are false");
// };

// ------------ Switch case--------

let a = 10;
let b = 12;

// a + b = Expression
// a + b === 13

switch (a + b) {
  case 13:
    console.log("10 + 3 is = 13");
    break;
  // 10 + 12 === 22
  case 21:
    console.log("10 + 12 = 22");
    break;
  case 26:
    console.log("10 + 12 = 22 second time");
    break;
  case 25:
    console.log("10 + 12 = 25");
    break;

  // else
  default:
    console.log("All the above cases are false");
}
