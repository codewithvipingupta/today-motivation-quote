// -------- For Loop------

// 3 things
// 1. Initilize
// 2. Terminating condition
// 3. Increment / decrement

// i++ ---> i = i+1;

// console.log("For loop");
// for(let i = 0 ; i < 5 ; i++)
// {
//     console.log(i);
// }
// console.log("Loop terminated");

// 0 1 2 3 4

// 5 < 5---> False

//------- While Loop-------

// Initilization
// let i = 0;

// // while(Condition)

// console.log("While loop");
// while(i < 5)
// {
//     console.log(i);

//     // increment/decrement oper
//     i++;
// }
// console.log('While loop terminated');

// ------ Do while loop-------

// Do whote loop --- > Atlest one time perform

// let i = 0;

// do{
//     console.log(i);
// } while(i > 0)

// i = -1;
// 5 4 3 2 1 0

//--------------- For In Loop-----

// const obj = {
//     a : 1,
//     b : 2,
//     c : 3,
// };

// for(i in obj)
// {
//     console.log(obj[i]);
// }

// ------------- For of Loop---------

// const arr = [1, 2, 3, 4, 5];
// //const a = 1;

// for(const i of arr)
// {
//     console.log(i);
// }

// for of loop in objects

// const obj = {
//     a : 1,
//     b : 2,
//     c : 3,
// };

// Object.entries = [key, value];

// for(let [key, value] of Object.entries(obj))
// {
//     console.log(key + " " + value);
// }

// for(let i of Object.keys(obj))
// {
//     console.log(obj[i]);
// }

// console.log("Values")

// for(let i of Object.values(obj))
// {
//     console.log(i);
// }

//------------- forEach Loop------------

const nums = [1, 2, 3, 4, 5];

// nums.forEach(
//     function (i){
//         console.log(i);
//     }
// )

function numsArray(i) {
  console.log(i);
}

//nums.forEach(numsArray);

// ------------- Functions--------------

// A Block of code which we can re-use

function hello() {
  console.log("Hello");
}

// Funmction call;

// hello();

// Function with parameters

function add(a, b) {
  let c = a * a * a;
  let d = b * b * b;
  let e = c + d;
  console.log(e);
}

// function call
// add(1, 2);
// add(12, 32);

// 1 + 8 = 9

// function with return value

function greet(i) {
  return "Good Morning " + i;
}

//const abc = greet("Nikhil");
//console.log(greet("Nikhil"));

function sum(a, b) {
  return a + b;
}
const c = sum(12, 10);
// console.log(c);

//-------- Arrow Function-------

// const fun = () => {
//     console.log("Hii I am arrow function")
// }

// const fun = (a, b) => {
//     console.log("Sum is : " + (a+b))
// }

// const fun = (a, b) => console.log("Sum is : " + (a + b));


const fun = (a, b) => a+b;

const z = fun(12, 10);
console.log(z);
